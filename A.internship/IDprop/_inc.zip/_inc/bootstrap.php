<?php include sprintf('%s/env.php', __DIR__); ?>
<link rel="stylesheet" type='text/css' href="<?php echo $path;?>/assets/bootstrap/css/bootstrap.min.css">
<script type="application/javascript" src="<?php echo $path;?>/assets/bootstrap/js/jquery.min.js"></script>
<link rel="stylesheet" href="<?php echo $path;?>/assets/bootstrap/css/jquery-ui.css">
<script src="<?php echo $path;?>/assets/bootstrap/js/jquery-ui.js"></script>
<script src="<?php echo $path;?>/assets/bootstrap/js/bootstrap.min.js"></script>