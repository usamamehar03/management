<?php # include __DIR__"./env.php"; 
?>
<footer class="footer" style="width: 100%;display: block;margin-top: 50px;float: left;">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<center class="footer_intro">
					<div class="footer_cr" style="margin-top: 0px !important;display: inline !important;">
						Copyright ©2020 All rights reserved
					</div>
				</center>
			</div>				
			<center class="col-lg-12" style="margin-top: -35px;text-align: center;">
				<div class="footer_link" style="float: unset;display: inline;">
					<a href="<?php echo $path;?>/privacy">Privacy Policy</a>
				</div>
				<div class="footer_link" style="float: unset;display: inline;" >
					<a href="<?php echo $path;?>/cookies">Cookie Policy | </a>
				</div>
				<div class="footer_link" style="float: unset;display: inline;" >
					<a href="<?php echo $path;?>/disclaimer">Disclaimer | </a>
				</div>
				<div class="footer_link" style="float: unset;display: inline-block;">
					<a href="<?php echo $path;?>/legal">Legal </a>
				</div>
			</center>
		</div>
	</div>
</footer>